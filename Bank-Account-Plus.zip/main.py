#Arnav Kondagunta - Bank Account Using Classes - 1/6/2022
#import random integer function
from random import randint
#Creates the class for the account
class Account:
  def __init__(Self, name, id, balance, password):
    Self.name = name
    Self.id = id
    Self.balance = balance
    Self.password = password
  
  #prints current balance (including after deposits, withdrawals, and transfers)
  def check_balance(Self):
    print(Self.name,"has", Self.balance, "dollars in their bank account")

  #allows the user to deposit money
  def deposit(Self, amount):
    Self.amount = amount
    print("Your old balance:", Self.balance, "dollars")
    Self.balance += Self.amount
    print("Your new balance", Self.balance, "dollars")

  #allows the user to withdraw money
  def withdraw(Self, amount):
    Self.amount = amount
    print("Your old balance:", Self.balance, "dollars")
    Self.balance -= Self.amount
    #doesn't allow user to withdraw more than the account has
    if Self.balance < 0:
      print("You are withdrawing more than the amount within this account. The withdrawal will not go through.")
      Self.balance += Self.amount
    else:
      print("Your new balance:", Self.balance, "dollars")
  
  #allows the user to create a new account
  def create_account(Self):
    #randomly generates the id  
    Self.id = randint(1000000, 9999999)
    for x in account_holders_info:
      #on the off chance the generated id is the same as an already taken id, it regenerates the id to reduce the probability of having two same ids
      if Self.id in account_holders_info[x].values():
       Self.id = randint(1000000, 9999999)
       break
    #adds the new account's information to the list and dictionary
    account_holders.append(Self.name)
    account_holders_info[Self.name] = {"id" : Self.id, "balance" : float(0), "password" : Self.password}
    print("\nYour new account has been created.")
    print("Name:", Self.name, "\nID:", Self.id, "\nBalance:", Self.balance, "\nPassword:", Self.password)
  
  #allows the user to transfer funds to another member of the bank
  def transfer_funds(Self, account, amount):
    account.balance += amount
    Self.withdraw(amount)
    #updates the dictionary and deposits the money into the person-money-is-being-transfered-to's account
    account_holders_info[account.name] = {"id" : account.id, "balance" : account.balance, "password" : account.password}
      
  #allows the user to list the accounts at my bank
  def list_accounts(Self):
    print("\nOur account holders:", account_holders)
    print("Number of accounts at our bank:", len(account_holders))

#allows user to choose from specified account holders
#list is for the user to see the account holders
account_holders = ["Bryan Ly", "Nick Almodovar", "Jake Leyzerovich", "Dr. Wiener"]
#nested dictionary with account information
account_holders_info = {
  "Bryan Ly" : {
    "id" : 4607439,
    "balance" : float(573946),
    "password" : "bly2022" },
  "Nick Almodovar" : {
    "id" : 2821748,
    "balance" : float(978647),
    "password" : "nalmodovar2022" },
  "Jake Leyzerovich" : {
    "id" : 6921048,
    "balance" : float(386132),
    "password" : "jleyzerovich2022" },
  "Dr. Wiener" : {
    "id" : 8462841,
    "balance" : float(957926),
    "password" : "swiener2022" }
  }

while True:
  #asks the user to either access of create an account
  access_or_create = input("Are you accessing or creating an account? (type 'end' to end your session)\n")
  if access_or_create == "access" or access_or_create == "accessing":
    print(account_holders)
    account_input = input("\nWho's bank account are you accessing?\n")
    #ensures the account they are trying to access is an account at my bank
    if account_input in account_holders:
      #creates the object using information from the dictionary
      a1 = Account(account_input, account_holders_info[account_input]["id"], account_holders_info[account_input]["balance"],account_holders_info[account_input]["password"])
      account_actions = True
      while account_actions != "exit":
        #asks the user for the password to the account
        ask_password = input("What is the password for this account?\n")
        if ask_password == a1.password:
          print("Account ID:", a1.id)
          #asks user what they want to do within the account
          while account_actions != "exit":
            account_actions = input("\nWould you like to check balance, deposit, withdraw, transfer funds, list accounts, or exit your account?\n")
            if account_actions == "check balance":
              while True:
                #asks for password before displaying account's balance
                ask_password = input("Please input your password:\n")
                if ask_password == a1.password:
                  a1.check_balance()
                  break
                else:
                  print("Incorrect password, try again.")
            elif account_actions == "deposit":
              a1.deposit(float(input("How much are you depositing?\n")))
            elif account_actions == "withdraw":
              a1.withdraw(float(input("How much are you withdrawing?\n")))
            elif account_actions == "transfer funds":
              while True:
                transfer_to = input("Who are you transferring funds to?\n")
                if transfer_to in account_holders:
                  #ensures the user is not transferring funds to themselves
                  if transfer_to == account_input:
                    print("You cannot transfer funds to yourself.")
                  else:
                    a2 = Account(transfer_to, account_holders_info[transfer_to]["id"], account_holders_info[transfer_to]["balance"],account_holders_info[transfer_to]["password"]) 
                    a1.transfer_funds(a2,float(input("How much are you transferring?\n")))
                    break
                #ensures the user is transferring funds to an actual account at the bank
                else:
                  print("That is not one of our account holders. Please try again.")

            elif account_actions == "list accounts":
              a1.list_accounts()
              
            elif account_actions == "exit":
                break
            
            #ensures the user input action is a given option
            else:
              print("Sorry, that's not one of the options. Please try again.") 
        #line will run when the password is incorrect
        else:
          print("Incorrect password. Try again.")
          
      #ensures the user's input is an account holder
    else:
      print("That is not one of the account holders here, please try again.\n")

  #allows user to create an account
  elif access_or_create == "create" or access_or_create == "creating":
    new_account_name = input("What is the name of the account holder?\n")
    while True:
      new_account_password = input("What is will be the password?\n")
      #confirms password so user does not input password incorrectly
      confirm_password = input("Please reinput your password for confirmation:\n")
      if new_account_password == confirm_password:
        a1 = Account(new_account_name, 0, float(0), new_account_password).create_account()
        break
      else:
        print("The passwords do not match. Please try again.")
  
  #allows the user to end the session
  elif access_or_create == "end":
    print("Thank you for using my bank.")
    break